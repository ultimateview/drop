if (!utils) { utils = {}; }
if (!utils.camera) { utils.camera = {}; }
utils.camera.WASD = (camera) => {
    camera.keysUp.push(87);
    camera.keysDown.push(83);
    camera.keysLeft.push(65);
    camera.keysRight.push(68);
    return camera;
};

utils.camera.AddFollowCamera = (name, target, radius, height, scene, attachWasdTo = null) => {
    const cam = new BABYLON.FollowCamera(
        name,
        BABYLON.Vector3.Zero(),
        scene
    );
    
    cam.lockedTarget = target;
    cam.radius = radius;
    cam.heightOffset = height;

    if (attachWasdTo) {
        cam.attachControl(attachWasdTo, true);
    }
    return cam;
};

utils.camera.AddArcRotateCamera = (
        name, 
        delta,
        radius,
        targetPosition,
        scene,
        attachWasdTo = null
    ) => {

    const cam = new BABYLON.ArcRotateCamera(
        name,
        BABYLON.Tools.ToRadians(delta),
        BABYLON.Tools.ToRadians(delta),
        radius,
        targetPosition,
        scene
    );

    if (attachWasdTo) {
        cam.attachControl(attachWasdTo, true);
    }
    return cam;
};

utils.camera.AddFreeCamera = (
        name, 
        direction, 
        scene,
        attachWasdTo = null
    ) => {
    const cam = new BABYLON.FreeCamera(
        name, 
        direction, 
        scene
    );

    cam.setTarget(BABYLON.Vector3.Zero());

    if (attachWasdTo) {
        cam.attachControl(attachWasdTo, true);
        utils.camera.WASD(cam);
    }
    return cam;
};
