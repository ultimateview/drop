if (!utils) { utils = {}; }
if (!utils.mesh) { utils.mesh = {}; }

utils.mesh.Cube = (name, size, scene) => {
    return BABYLON.Mesh.CreateBox(name, size, scene);
};

utils.mesh.GroundBox = (name, size, scene) => {
    //const m = BABYLON.Mesh.CreateBox(name, size, scene);
    const m = utils.mesh.Plane(name, size, scene);
    m.rotation.x = BABYLON.Tools.ToRadians(-90);
    m.applyGravity = false;
    m.physicsImpostor = new BABYLON.PhysicsImpostor(m, BABYLON.PhysicsImpostor.BoxImpostor, { mass: 0, restitution: 0.9 }, scene);
    return m;
};

utils.mesh.Plane = (name, size, scene) => {
    //return BABYLON.MeshBuilder.CreatePlane(name, { width: size, height: size }, scene);
    return BABYLON.MeshBuilder.CreatePlane(name, { width: size, height: size, sideOrientation: BABYLON.Mesh.DOUBLESIDE }, scene);
};

utils.mesh.Ground = (name, size, scene) => {
    return BABYLON.MeshBuilder.CreateGround(name, { width: size, height: size, subdivisions: 4 }, scene);
};





utils.mesh.material = {};

utils.mesh.material.Wireframe = (name, scene) => {
    const m = new BABYLON.StandardMaterial(name, scene);
    m.wireframe = true;
    return m;
};

utils.mesh.material.Standard = (name, scene) => {
    const m = new BABYLON.StandardMaterial(name, scene);
    m.wireframe = false;
    return m;
};

utils.mesh.material.Image = (name, path, scene) => {
    const m = new BABYLON.StandardMaterial(name, scene);
    m.specularTexture = new BABYLON.Texture(path, scene);
    return m;
};