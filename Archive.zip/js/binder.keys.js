const keyBinder = {
    keys: {},
    subscribers: [],
    watching: null,
    notify: (keyCode, isDown) => {
        for (let i = 0; i < keyBinder.subscribers.length; i++) {
            //log(keyCode + ' vs ' + keyBinder.subscribers[i].keyCode);
            if (keyCode == keyBinder.subscribers[i].keyCode) {
                keyBinder.subscribers[i].handler({ keyCode: keyCode, isDown: isDown });
            }
        }
    }
};

keyBinder.setWatch = (el) => {
    keyBinder.watching = $(el);
    keyBinder.watching.on('keydown', (evt) => {
        const keyCode = evt.which;
        keyBinder.keys[keyCode.toString()] = true;
        keyBinder.notify(keyCode, keyBinder.keys[keyCode.toString()]);
    });
    keyBinder.watching.on('keyup', (evt) => {
        const keyCode = evt.which;
        keyBinder.keys[keyCode.toString()] = false;
        keyBinder.notify(keyCode, keyBinder.keys[keyCode.toString()]);
    });
};

keyBinder.subscribe = (keyCode, handler) => {
    
    if (typeof keyCode == 'number') {
        keyBinder.subscribers.push({
            keyCode: keyCode,
            handler: handler
        });
    } else if (typeof keyCode == 'object') {
        for (let i = 0; i < keyCode.length; i++) {
            keyBinder.subscribers.push({
                keyCode: keyCode[i],
                handler: handler
            });
        }
    }
    
};
