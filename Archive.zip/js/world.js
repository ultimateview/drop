const utils = {
    mesh: null
};

const world = {
    config: {
        logging: true
    },
    log: function(msg) {
        if (world.config.logging && (typeof console != 'undefined' && (typeof console.log != 'undefined'))) {
            console.log(msg);
        }
    },
    objects: {},
    physics: {
        enabled: true
    }
};
const log = world.log;

window.addEventListener('DOMContentLoaded', () => {
    world.canvas = $('#world').get(0);
    if (!world.canvas) { log('No canvas context, aborting.'); return false; }

    world.engine = new BABYLON.Engine(world.canvas, true);

    const createScene = () => {
        world.scene = new BABYLON.Scene(world.engine);
        world.scene.clearColor = new BABYLON.Color3.Black();

        let gravityVector = new BABYLON.Vector3(0, -9.81, 0);
        const physicsPlugin = new BABYLON.CannonJSPlugin();
        if (world.physics.enabled) {
            world.scene.enablePhysics(gravityVector, physicsPlugin);
        }

        let ground = utils.mesh.GroundBox('floor', 17, world.scene);
        //ground.material = utils.mesh.material.Wireframe('ground-material', world.scene);
        //ground.material = utils.mesh.material.Standard('ground-material', world.scene);
        ground.material = utils.mesh.material.Image('ground-material', 'img/texture/marble-checkerboard.jpg', world.scene);
        
        //ground.position.y = -80;
        ground.checkCollision = true;
        ground.applyGravity = false;
        window.ground = ground;

        var light1 = new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(2, 2, 1), world.scene);
        light1.intensity = 0.33;
        var light2 = new BABYLON.PointLight("light2", new BABYLON.Vector3(0, 2, -1), world.scene);
        var light3 = new BABYLON.PointLight("light3", new BABYLON.Vector3(0, -2, 1), world.scene);
        var spotLight = new BABYLON.SpotLight("spotLight", new BABYLON.Vector3(0, 6, -3), new BABYLON.Vector3(0, -1, -1), Math.PI / 3, 2, world.scene);

        light2.intensity = light3.intensity = 0.5;

        
        let box1 = utils.mesh.Cube('box1', 4.0, world.scene);
        box1.applyGravity = false;
        //box1.position.y = 50;
        world.objects.box1 = box1;

        let box2 = utils.mesh.Cube('box2', 3.0, world.scene);
        world.objects.box2 = box2;
        //box2.material = utils.mesh.material.Wireframe('material1', world.scene);
        box2.position = new BABYLON.Vector3(0, 5, 0);
        

        //box1.addChild(box2);
        box1.position.y = 40;



        //ground.physicsImpostor = new BABYLON.PhysicsImpostor(ground, BABYLON.PhysicsImpostor.BoxImpostor, { mass: 0, restitution: 0.9 }, scene);
        if (world.physics.enabled) {
            box1.physicsImpostor = new BABYLON.PhysicsImpostor(box1, BABYLON.PhysicsImpostor.BoxImpostor, { mass: 10, restitution: 0.9 }, world.scene);
        }

        //world.camera = utils.camera.AddFreeCamera('camera1', new BABYLON.Vector3( 0, 0, -10), world.scene, world.canvas);
        world.camera = utils.camera.AddArcRotateCamera('camera1', 45, 20, BABYLON.Vector3.Zero(), world.scene, world.canvas);
        //world.camera = utils.camera.AddFollowCamera('camera1', box1, 22, 10, world.scene, world.canvas);
        
        /*  keyBinder can watch key events on any DOM element. 
            In some cases, it may be best to watch the entire window, in other cases, just the 3D viewport.
         */
        //keyBinder.setWatch(world.canvas);
        keyBinder.setWatch(window);

        /* .subscribe() registers listeners to be updated whenever the key event is triggered. 
            This is not the same as watching the down/up state, but rather just notification when DOM event fires. 
         */
        keyBinder.subscribe([65, 68], (obj) => {
            log('key: ' + obj.keyCode + ' isDown: ' + obj.isDown);
            switch (obj.keyCode) {
                case 65:    box1.rotation.z += 0.1;
                            break;
                case 68:    box1.rotation.z -= 0.1;
                            break;
                default:    break;
            }
        });

        /* .subscribe() can be used to wrap its DOM-based event handlers in a more real-time approach
            using a local flag to keep track of real-time isDown status. 
         */
        let isWDown = false;
        keyBinder.subscribe(87, (obj) => {
            isWDown = obj.isDown;
        });
        let isWTimer = setInterval((e) => {
            if (isWDown) {
                box1.rotation.x += 0.01;
            }
        }, 1);



        return world.scene;
    };

    $(world.canvas).trigger('click');
    createScene();

    world.engine.runRenderLoop(() => {
        //world.objects.box1.position.z += 0.05;
        //world.scene.getMeshByName('box1').position.z += 0.05;
        world.scene.render();
    });


});